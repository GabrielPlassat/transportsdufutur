---
title: "Covoiturage domicile travail"
date: 2013-02-27 16:42:52
permalink: https://gabrielplassat.github.io/transportsdufutur/2013/02/covoiturage-domicile-travail.html
tags: [nan]
---

<p style="text-align: justify;">Trois salariés d’une entreprise bretonne localisée en zone rurale à Sainte-Marie, au lieu-dit La Couplais (dans la périphérie Redonnaise), ont mis en place un système de transport collectif alliant les effets bénéfiques du covoiturage et de la voiture partagée : à l’automne 2012, ils ont fait l’achat en commun d’un véhicule d’occasion qu’ils dédient exclusivement à leurs trajets domicile-travail... Si vous avez des questions, des propositions ... Contacter <strong><a href="mailto:sebastien.gonguet@mobhilis.fr" target="_self">Mobhilis</a></strong>.</p> <p> <iframe width="450" frameborder="0" src="http://prezi.com/embed/uzcn2oqyd5sp/?bgcolor=ffffff&lock_to_path=0&autoplay=no&autohide_ctrls=0&features=undefined&disabled_features=undefined" height="400"></iframe></p>
