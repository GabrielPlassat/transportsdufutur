---
title: "Votre avis sur le blog Les Transports du Futur !"
date: 2010-11-30 16:55:56
permalink: https://gabrielplassat.github.io/transportsdufutur/2010/11/votre-avis-sur-le-blog-les-transports-du-futur.html
tags: [nan]
---

<p style="text-align: justify"><span style="font-size: 10pt">Après une année d'existance, un premier bilan s'impose. <strong><a href="http://web.questback.com/ademe/transportsdufutur/" target="_blank">Pouvez vous donner votre avis sur le blog en cliquant ICI ? </a></strong>Merci beaucoup pour votre participation à ce sondage (1 clic).</span></p>
