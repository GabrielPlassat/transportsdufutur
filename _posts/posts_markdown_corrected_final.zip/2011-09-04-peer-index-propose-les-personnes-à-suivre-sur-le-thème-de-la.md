---
title: "Peer Index propose les personnes à suivre sur le thème de la Prospective"
date: 2011-09-04 22:14:23
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/09/peer-index-propose-les-personnes-a-suivre-sur-le-theme-de-la-prospective.html
tags: [internet, réseaux]
---

<p style="text-align: justify;"><a href="http://www.peerindex.com" target="_blank"><strong>Peer Index</strong></a> estime, sur la base de votre activité sur internet et des flux générés par vos articles, tweets ou encore de votre réseau, trois notes : l'audience, l'autorité et l'activité puis une note globale. Les personnes de ce groupe créé par <a href="http://www.peerindex.com/mitchbetts" title="Mitch Betts">Mitch Betts</a> sont classées par leur indice global. Chaque personne ou organisation est identifiée par plusieurs mots clés correspondants à leurs activités principales.</p> <p><iframe height="600" src="http://api.peerindex.net/1/embed/group?profile=mitchbetts&group=futurists" width="500"></iframe></p>
