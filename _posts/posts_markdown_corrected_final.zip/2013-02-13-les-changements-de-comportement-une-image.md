---
title: "Les changements de comportement : une image"
date: 2013-02-13 11:49:03
permalink: https://gabrielplassat.github.io/transportsdufutur/2013/02/les-changements-de-comportement-une-image.html
tags: [CERTU, citoyen, commuter, économie de l'expérience, Efficacité énergétique, multimodes, Service de mobilité, transit]
---

<p style="text-align: justify">Ces changements de comportement sont rapides. La possession exclusive de l'automobile individuelle privée se réduit, la multimodalité se développe. Quand l'effet lié à l'âge des acheteurs se fera sentir (d'ici 5 ans), une nouvelle vague de chute des ventes des véhicules neufs s'enclenchera. D'autres modèles d'affaires sont accessibles, mais ils sont plus <strong><a href="https://gabrielplassat.github.io/transportsdufutur/les-metanotes-tdf-transports-du-futur" target="_blank">complexes</a></strong>.</p> <p style="text-align: justify">Bienvenue dans l'industrialisation de nouveaux systèmes de mobilité.</p> <p> <a class="asset-img-link" href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b017d410605af970c-pi.png"><img alt="Multimod2" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b017d410605af970c image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b017d410605af970c-800wi.png" title="Multimod2" /></a></p> <p> </p>
