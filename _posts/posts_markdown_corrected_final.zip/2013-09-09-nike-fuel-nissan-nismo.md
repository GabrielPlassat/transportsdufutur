---
title: "Nike+ Fuel / Nissan Nismo"
date: 2013-09-09 16:35:19
permalink: https://gabrielplassat.github.io/transportsdufutur/2013/09/nike-fuel-nissan-nismo.html
tags: [assistant de mobilité, jeu, jeu vidéo, marche, monnaie complémentaire]
---

<p style="text-align: justify;">Déjà présenté (lire <strong><a href="https://gabrielplassat.github.io/transportsdufutur/2012/01/super-a-160-eurolitre-passer-a-nike-fuel.html" target="_blank">Super à 1.6 €/litre, passer à Nike Fuel</a></strong>), Nike Fuel incarne une certaine idée des mobilités actives. Nissan innove avec Nismo Watch, pour être connecté à son véhicule et partager ses mobilités motorisées. D'après vous, qui incarne le mieux les prochains imaginaires ?  </p> <iframe frameborder="0" height="315" src="//www.youtube.com/embed/8lRfJS4bcyM" width="560"></iframe> <iframe frameborder="0" height="315" src="//www.youtube.com/embed/v4Wjpe0ZOxY" width="560"></iframe>
