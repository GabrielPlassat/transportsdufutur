---
title: "Véhicules à 3 litres / 100 km, retour vers le passé 1980 #ademe #afme"
date: 2011-12-08 16:10:59
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/12/vehicules-a-3-litres-100-km-retour-vers-le-passe-1980-ademe-afme.html
tags: [ADEME, véhicule propre]
---

<p>     </p>
