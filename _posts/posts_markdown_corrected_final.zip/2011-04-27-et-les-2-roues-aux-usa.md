---
title: "Et les 2 roues aux USA ?"
date: 2011-04-27 09:17:38
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/04/et-les-2-roues-aux-usa.html
tags: [2 roues, Service de mobilité, véhicule propre]
---

<p>From <strong><a href="http://mashable.com/2011/04/26/scooters-environmental-infographic/" target="_blank">Mashable </a></strong>:</p> <p><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b01538e2641e6970b-pi.png"><img alt="Scooter-infographic" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b01538e2641e6970b image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b01538e2641e6970b-800wi.png" title="Scooter-infographic" /></a> </p>
