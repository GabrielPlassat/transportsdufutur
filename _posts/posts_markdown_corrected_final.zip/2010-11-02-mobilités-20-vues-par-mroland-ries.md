---
title: "Mobilités 2.0 vues par M.Roland Ries"
date: 2010-11-02 11:20:22
permalink: https://gabrielplassat.github.io/transportsdufutur/2010/11/mobilites-20-vues-par-mroland-ries.html
tags: [autorité des transports, cité, citoyen, collectivité, partage de données, Service de mobilité]
---

<p style="text-align: justify">Interview de Roland Ries, Sénateur et Maire de Strasbourg, président du GART (Groupement des Autorités Responsables de Transports), à l'occasion du salon Transports Publics en juin 2010 à Paris. Questions à l'élu suivies par un extrait de la conférence La mobilité durable dans les grandes métropoles européennes".</p> <p>En résumé :</p> <ol> <li>Apprendre à connaître les flux des mobilités</li> <li>Développer des solutions multimodales adaptées aux territoires</li> <li>Repenser la gouvernance globale pour atteindre des objectifs en utilisant de nouveaux leviers</li> </ol> <p>        <br /><strong><a href=""http://www.dailymotion.com/video/xfb6s5_la-mobilite-durable-vue-par-roland_news"">La mobilité durable vue par Roland Ries</a></strong><br /><em>envoyé par <a href=""http://www.dailymotion.com/innovcity"">innovcity</a>. - <a href=""http://www.dailymotion.com/fr/channel/news"">L'info video en direct.</a></em></p>"
