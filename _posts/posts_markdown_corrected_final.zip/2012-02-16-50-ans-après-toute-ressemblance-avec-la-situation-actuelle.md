---
title: "50 ans après, toute ressemblance avec la situation actuelle ne serait que pure fiction ..."
date: 2012-02-16 10:02:55
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/02/50-ans-apres-toute-ressemblance-avec-la-situation-actuelle-ne-serait-que-pure-fiction.html
tags: [Efficacité énergétique, véhicule mono-usage]
---

<p><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0168e770df75970c-pi.jpg"><img alt="Peelp50" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b0168e770df75970c image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0168e770df75970c-800wi.jpg" title="Peelp50" /></a></p> <p>D'autres exemples <a href="https://plus.google.com/photos/104159637514231145250/albums/5709655501977217857?authkey=CMD4o5veidDrjgE" target="_blank"><strong>ICI</strong></a>.</p>
