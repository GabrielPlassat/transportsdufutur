---
title: "The Future of Transportation - Synthesis in 20 slides"
date: 2011-10-24 21:24:08
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/10/the-future-of-transportation-synthesis-in-20-slides.html
tags: [assistant de mobilité, assurance, autopartage, autorité des transports, citoyen, collectivité, commuter, confiance, congestion, donnée data, données réelles, economie circulaire, économie du quaternaire, économie fonctionnalité, Efficacité énergétique, Energie, gouvernance, holoptisme, Infrastructure, innovation, internet, léger, living lab, management de la mobilité, marketing individualisé, mode doux, multimodes, open innovation, partage de données, partage de la voirie, Pay as You Move, péage urbain, pensée complexe, plate-forme, qualité de l'air, Service de mobilité, simplicité, TIC, transit, yield management]
---

<div id="__ss_9861651" style="width: 425px"><strong style="margin: 12px 0 4px"><a href="http://www.slideshare.net/transportsdufutur/td-f-2011v1" title="Td f 2011v1">Td f 2011v1</a></strong>        <div style="padding: 5px 0 12px">View more <a href="http://www.slideshare.net/">presentations</a> from <a href="http://www.slideshare.net/transportsdufutur">Les transports du futur</a>.</div> </div>
