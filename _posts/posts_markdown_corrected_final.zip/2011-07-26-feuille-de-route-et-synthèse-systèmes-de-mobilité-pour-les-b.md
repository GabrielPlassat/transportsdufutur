---
title: "Feuille de route et synthèse Systèmes de mobilité pour les biens et les personnes"
date: 2011-07-26 11:44:14
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/07/feuille-de-route-et-synthese-systemes-de-mobilite-pour-les-biens-et-les-personnes.html
tags: [ADEME, assistant de mobilité, Assistant Personnel de Consommation, autorité des transports, citoyen, collectivité, connectivité, données réelles, gouvernance, internet des objets, management de la mobilité, open innovation, partage de données, partage de la voirie, PAYD, plate-forme, Service de mobilité]
---

<div id="__ss_8690529" style="width: 477px"><strong style="margin: 12px 0 4px"><a href="http://www.slideshare.net/transportsdufutur/feuille-deroute-mobilite1" title="Feuille deroute mobilite[1]">Feuille deroute mobilite[1]</a></strong>         <div style="padding: 5px 0 12px">View more <a href="http://www.slideshare.net/">documents</a> from <a href="http://www.slideshare.net/transportsdufutur">transportsdufutur</a>.</div> </div> <div id="__ss_8690531" style="width: 477px"><strong style="margin: 12px 0 4px"><a href="http://www.slideshare.net/transportsdufutur/synthese-feuillederoute-mobilite1" title="Synthese feuillederoute mobilite[1]">Synthese feuillederoute mobilite[1]</a></strong>        <div style="padding: 5px 0 12px">View more <a href="http://www.slideshare.net/">documents</a> from <a href="http://www.slideshare.net/transportsdufutur">transportsdufutur</a>.</div> </div>
