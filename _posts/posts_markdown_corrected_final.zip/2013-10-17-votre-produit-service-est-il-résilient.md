---
title: "Votre produit / service est-il résilient ?"
date: 2013-10-17 17:33:39
permalink: https://gabrielplassat.github.io/transportsdufutur/2013/10/resilience-et-evenements-from-les-transports-du-futur.html
tags: [nan]
---

<iframe src="http://www.slideshare.net/slideshow/embed_code/27299936" width="450" height="420" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;"> </iframe> <div style="margin-bottom: 5px;"> <strong> <a title="Résilience et evenements3" href="https://fr.slideshare.net/transportsdufutur/rsilience-et-evenements3" target="_blank">Résilience et evenements3</a> </strong> from <strong><a href="http://www.slideshare.net/transportsdufutur" target="_blank">Les transports du futur</a></strong> </div>
