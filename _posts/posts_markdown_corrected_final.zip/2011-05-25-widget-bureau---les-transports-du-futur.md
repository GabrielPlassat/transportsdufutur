---
title: "Widget Bureau - Les Transports du Futur"
date: 2011-05-25 09:57:20
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/05/widget-bureau-les-transports-du-futur.html
tags: [ADEME, internet]
---

<p style="text-align: justify">Vous pouvez télécharger l'exécutable permettant d'avoir sur le bureau le flux d'informations venant du blog et des tweets (@tdf__ademe) : cliquer <strong><a href="http://desktopify.com/getwidget/Tweets%20Tdf" target="_blank">ICI</a></strong>.</p> <p> </p>
