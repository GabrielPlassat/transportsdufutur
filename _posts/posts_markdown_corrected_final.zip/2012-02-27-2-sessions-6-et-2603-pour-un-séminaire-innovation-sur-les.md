---
title: "2 sessions (6 et 26/03) pour un séminaire Innovation sur les Chaînes Logistiques et les Mobilités Occasionnelles pour répondre à l'AMI @ademe"
date: 2012-02-27 11:26:34
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/02/2-sessions-6-et-2603-pour-un-seminaire-innovation-sur-les-chaines-logistiques-et-les-mobilites-occas.html
tags: [nan]
---

<p><strong>Le 6 ou le 26/03 à Paris (La Cantine)</strong> - Tous les renseignements pour participer : <a href="http://www.ami-mobilite.com" target="_blank"><strong>www.ami-mobilite.com</strong></a></p> <p style="text-align: justify">Identifier des compétences, des innovations dans de nombreux domaines,  les rassembler  pour co-concevoir des projets produisant des livrables à  haute valeur ajoutée, proches du marché, positionnant favorablement les  acteurs français dans la chaîne de valeur.</p> <p style="text-align: justify">Nous comptons sur votre réseau pour faire connaître cet AMI et cette journée aux acteurs clés de ce domaine :</p> <ul style="text-align: justify"> <li>Start-up, PME, Laboratoires scientifiques des transports et de la  mobilité, socio-économie, des technologies de l’information, des usages,  …</li> <li>Entreprises dans de nombreux domaines : logistique, chargeur,  transporteur, industries des TIC, énergéticiens, gestionnaires  d’infrastructures (route, parking…), constructeurs de véhicule lourd et  léger, opérateurs de transport, banques et assurances, …</li> <li>Et collectivités (agglomération, département, région)…</li> </ul>
