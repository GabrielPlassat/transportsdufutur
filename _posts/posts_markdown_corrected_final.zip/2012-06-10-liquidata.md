---
title: "LiquiData"
date: 2012-06-10 21:49:17
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/06/liquidata.html
tags: [donnée data, données réelles, intelligence collective, internet, iphone, partage de données, téléphone, territoire, TIC, transition générationnelle]
---

<p style="text-align: justify;"><a href="http://www.liquidata.org/en/index.php" target="_blank"><strong>LiquiData</strong> </a>is a multitouch application to explore  your personal movement profile and to show other people engaging places  by adding photos and comments with the help of your smartphone.</p> <p> </p> <iframe src="http://player.vimeo.com/video/43120464?title=0&byline=0&portrait=0&color=f7f2f2" width="400" height="300" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
