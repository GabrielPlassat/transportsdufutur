---
title: "Les Transports du Futur - Les Laboratoires Vivants"
date: 2011-12-20 15:52:44
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/12/les-transports-du-futur-les-laboratoires-vivants.html
tags: [nan]
---

<p>Un <a href="https://gabrielplassat.github.io/transportsdufutur/les_transports_du_futur_l/" target="_blank"><strong>blog spécifique</strong></a> est crée pour suivre les différents projets retenus dans le cadre du <a href="http://www2.ademe.fr/servlet/KBaseShow?sort=-1&cid=96&m=3&catid=22687" target="_blank"><strong>Fond Démonstrateur</strong></a> et des Investissements d'Avenir sur le programme <a href="http://www2.ademe.fr/servlet/KBaseShow?sort=-1&cid=96&m=3&catid=24707" target="_blank"><strong>Véhicule du Futur</strong></a>.</p> <p>Ce blog rassemble les liens et les présentations des projets et permettra :</p> <ul> <li>une animation croisée de tous les acteurs,</li> <li>un suivi dynamique et actualisé des projets,</li> <li>de créer une base de connaissances des différents retours d'expériences</li> </ul> <p>Pour le moment, trois projets sont présentés, en attendant 2012... Le BLOG<strong> <a href="https://gabrielplassat.github.io/transportsdufutur/les_transports_du_futur_l/" target="_blank">Les Laboratoires Vivants</a></strong></p>
