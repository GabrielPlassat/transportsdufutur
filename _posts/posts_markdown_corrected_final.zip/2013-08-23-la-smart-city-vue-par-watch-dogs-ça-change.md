---
title: "La smart city vue par Watch Dogs, ça change ..."
date: 2013-08-23 10:59:34
permalink: https://gabrielplassat.github.io/transportsdufutur/2013/08/la-smart-city-vue-par-watch-dogs-ca-change.html
tags: [assistant de mobilité, cité, citoyen, connectivité, donnée data, données réelles, gouvernance, internet des objets, surveillance, virtuel]
---

<p style="text-align: justify;">La Smart city version<strong> <a href="http://watchdogs.ubi.com/watchdogs/fr-fr/game-info/index.aspx" target="_blank">Watch Dogs</a></strong>, heureusement ce n'est qu'un jeu ... Voir cette remarquable <strong><a href="http://wearedata.watchdogs.com/start.php?locale=fr-FR&city=paris" target="_blank">carte de Paris</a></strong>. Vous ne verrez plus la ville de la même façon. La carte, une puissante <strong><a href="https://gabrielplassat.github.io/transportsdufutur/2013/08/metanote-17-la-mutation-numerique-nengendre-pas-seulement-de-nouveaux-moyens-de-transports-elle-modi.html" target="_blank">matrice ontophanique</a></strong> qui explique pourquoi c'est une zone de combat.</p> <iframe frameborder="0" height="315" src="//www.youtube.com/embed/ZQRh6d7oUdA" width="560"></iframe>
