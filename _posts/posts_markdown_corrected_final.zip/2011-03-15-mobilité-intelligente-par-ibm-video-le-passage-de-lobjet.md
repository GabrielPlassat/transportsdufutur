---
title: "Mobilité intelligente par IBM (video), le passage de l'objet aux services"
date: 2011-03-15 18:01:58
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/03/mobilite-intelligente-par-ibm-video-le-passage-de-lobjet-aux-services.html
tags: [collectivité, données réelles, internet, internet des objets, management de la mobilité, open source, partage de la voirie, Pay as You Move]
---

<p><iframe frameborder="0" height="390" src="http://www.youtube.com/embed/V2UDrG5RJ4U" title="YouTube video player" width="480"></iframe></p> <p>Rejoignez le groupe de discussion LinkedIn : Smarter Transportation, et écouter également la présentation de Jamie Houghton (IBM) : <a href="http://scpro.streamuk.com/uk/player/Default.aspx?wid=8140&ptid=32&t=0">http://scpro.streamuk.com/uk/player/Default.aspx?wid=8140&ptid=32&t=0</a></p> <p> </p>
