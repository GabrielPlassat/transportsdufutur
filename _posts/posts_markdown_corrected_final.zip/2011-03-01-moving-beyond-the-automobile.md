---
title: "Moving beyond the Automobile"
date: 2011-03-01 22:30:24
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/03/moving-beyond-the-automobile-2.html
tags: [nan]
---

<p style="text-align: justify;"><strong><a href="http://www.streetfilms.org/moving-beyond-the-automobile/" target="_blank">Moving Beyond the Automobile</a></strong> is a ten part video series which explores solutions to the problem of automobile dependency.  It's a visual handbook that will help guide policy makers, advocacy organizations, teachers, students, and others into a world that values pedestrian plazas over parking lots and train tracks over highways.  Cars were then, and this is now.  Welcome to the future. </p>  <!--more-->   <p style="text-align: justify;"> </p> <p><iframe frameborder="0" height="315" id="vimeo_player" src="http://player.vimeo.com/video/16972435?js_api=1&js_swf_id=vimeo_player&title=0&byline=0&portrait=0&color=9086c0" width="560"></iframe></p> <p><iframe frameborder="0" height="315" id="vimeo_player" src="http://player.vimeo.com/video/19836629?js_api=1&js_swf_id=vimeo_player&title=0&byline=0&portrait=0&color=9086c0" width="560"></iframe></p> <p><iframe frameborder="0" height="315" id="vimeo_player" src="http://player.vimeo.com/video/20516876?js_api=1&js_swf_id=vimeo_player&title=0&byline=0&portrait=0&color=9086c0" width="560"></iframe></p>
