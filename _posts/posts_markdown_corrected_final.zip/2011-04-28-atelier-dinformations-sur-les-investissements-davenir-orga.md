---
title: "Atelier d'informations sur les Investissements d'Avenir organisé par l'ADEME"
date: 2011-04-28 11:28:44
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/04/atelier-dinformations-sur-les-investissements-davenir-organise-par-lademe.html
tags: [nan]
---

<p><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b014e881fce3d970d-pi.jpg"><img alt="Ia2" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b014e881fce3d970d image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b014e881fce3d970d-800wi.jpg" title="Ia2" /></a> <br />INSCRIPTION : <strong><a href="http://www.ademe-espaces.com/atelier/Home.1.html" target="_blank">ICI</a></strong></p> <p>PROGRAMME :</p> <div> <p>- Présentation générale des Investissement d´Avenir   de l´ADEME par Philippe Van de Maele, Président de l´ADEME</p> <p>- Objectifs et programmation par François Moisan Directeur Exécutif Stratégie, Recherche et International</p> <p>- Organisation et modalités d´intervention par Jean Guillaume Peladan, Directeur des Investissements d´Avenir</p> <p>- Répartition des participants dans les 4 ateliers :véhicule du futur et mobilité, énergies et reseaux, bioressources (biocarburants et chimie du végétal), économie circulaire</p> <p>- Présentation détaillée des différents AMI par les responsables de programmes et les ingénieurs référents</p> <p> </p> </div>
