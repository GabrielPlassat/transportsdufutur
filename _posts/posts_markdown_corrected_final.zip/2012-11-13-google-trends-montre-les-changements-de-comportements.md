---
title: "Google (trends) montre les changements de comportements"
date: 2012-11-13 12:03:03
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/11/google-trends-montre-les-changements-de-comportements.html
tags: [autopartage, citoyen, covoiturage, google, internet]
---

La Bretagne toujours en tête pour le covoiturage :
