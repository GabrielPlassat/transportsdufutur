---
title: "Eco Collab - Bordeaux - Rachel Botsman - De l'objet aux services"
date: 2013-07-05 11:14:06
permalink: https://gabrielplassat.github.io/transportsdufutur/2013/07/eco-collab-bordeaux-rachel-botsman-de-lobjet-aux-services.html
tags: [nan]
---

<p style="text-align: justify"><strong><a href="https://twitter.com/rachelbotsman" target="_blank">Rachel Botsman</a></strong> intervenait au <strong><a href="http://www.bordeaux-economie-collaborative.org/" target="_blank">Forum sur l'Economie Collaborative</a></strong>. La mobilité a bien sûr été mentionnée ...</p> <p style="text-align: justify"> <a class="asset-img-link" href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0192abe0c90a970d-pi.jpg"><img alt="20130704_105215" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b0192abe0c90a970d image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0192abe0c90a970d-800wi.jpg" title="20130704_105215" /></a><br /><br /></p> <p> </p>
