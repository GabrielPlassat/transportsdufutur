---
title: "Contribution ITS France à l'élaboration du Plan National ITS"
date: 2011-06-14 16:36:20
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/06/contribution-its-france-a-lelaboration-du-plan-national-its.html
tags: [ITS, multimodes, open source, TIC]
---

<p>Vous pouvez apporter des compléments / propositions directement dans le document ci dessous. Vos remarques seront intégrées et prises en compte afin de préparer une prochaine réunion de travail (28 juin) réunissant MEDDTL/DGITM, SETRA, CERTU, ASFA, PREDIM et ATEC ITS France.</p> <p><iframe height="600" src="http://crocodoc.com/On7FlTe?embedded=true" style="border: 1px solid #ddd;" width="100%"></iframe></p>
