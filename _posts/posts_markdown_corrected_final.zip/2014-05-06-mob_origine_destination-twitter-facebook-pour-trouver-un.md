---
title: "#Mob_origine_destination (Twitter, Facebook) pour trouver une solution de mobilité"
date: 2014-05-06 08:30:29
permalink: https://gabrielplassat.github.io/transportsdufutur/2014/05/mob_origine_destination-twitter-facebook-pour-trouver-une-solution-de-mobilite.html
tags: [nan]
---

<p style="text-align: justify;">Après <a href="http://www.01net.com/editorial/617672/amazon-dash-la-telecommande-d-amazon-pour-faire-ses-courses/" target="_blank"><strong>Amazon Dash</strong></a> (télécommande pour faire ses courses), Amazon vient de proposer <strong><a href="http://www.01net.com/editorial/619262/avec-amazoncart-remplissez-votre-panier-amazon-directement-sur-twitter/" target="_blank">#AmazonCart</a>.</strong> Il est essentiel d'utiliser les plateformes dominantes plutôt que d'essayer de faire venir les utilisateurs sur une nouvelle. AmazonCard permet de rajouter dans votre panier (pas d'acheter) un produit vu sur Twitter en ajoutant simplement au tweet #AmazonCart. </p> <p style="text-align: justify;"><iframe allowfullscreen="" frameborder="0" height="315" src="//www.youtube.com/embed/iAm6pa9hPKA?rel=0" width="560"></iframe></p> <p>De la même façon, pourrait-on faire sur Twitter et Facebook : #Mob_paris_marseille_date_passager (ou conducteur) pour alimenter automatiquement ses comptes Blablacar, Drivy ou Buzzcar ? </p>
