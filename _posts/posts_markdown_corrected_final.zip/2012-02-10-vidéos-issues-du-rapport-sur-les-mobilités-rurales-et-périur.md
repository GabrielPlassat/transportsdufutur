---
title: "Vidéos issues du Rapport sur les mobilités rurales et périurbaines par le Centre d’Analyse Stratégique @strategie_gouv @ademe"
date: 2012-02-10 11:45:08
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/02/videos-issues-du-rapport-sur-les-mobilites-rurales-et-periurbaines-par-le-centre-danalyse-strategiqu.html
tags: [collectivité, confiance, connectivité, donnée data, gouvernance, Infrastructure, innovation, maison de la mobilité, management de la mobilité, open innovation, Santé, Service de mobilité]
---

<p>Le rapportest disponible <a href="http://www.strategie.gouv.fr/content/pour-une-nouvelle-approche-des-mobilites-dans-les-territoires-periurbains-et-ruraux-note-de-" target="_blank"><strong>ici</strong></a>, les vidéos lors de la remise de ce rapport :</p> <p><iframe frameborder="0" height="270" src="http://www.dailymotion.com/embed/video/xoh1md_les-nouvelles-mobilites-dans-les-territoires-periurbains-et-ruraux-vincent-chriqui_news" width="480"></iframe><br /><a href="http://www.dailymotion.com/video/xoh1md_les-nouvelles-mobilites-dans-les-territoires-periurbains-et-ruraux-vincent-chriqui_news" target="_blank">Les nouvelles mobilités dans les territoires...</a> <em>par <a href="http://www.dailymotion.com/centreanalysestrategique" target="_blank">centreanalysestrategique</a></em></p>
