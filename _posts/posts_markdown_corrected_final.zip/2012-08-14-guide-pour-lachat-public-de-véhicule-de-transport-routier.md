---
title: "Guide pour l'achat public de véhicule de transport routier, Application de la Directive Européenne Véhicule Propre et Econome''"
date: 2012-08-14 10:19:00
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/08/guide-pour-lachat-public-de-vehicule-de-transport-routier-application-de-la-directive-europeenne-veh.html
tags: [externalité, véhicule propre]
---

<p style="text-align: justify;">La directive européenne est accessible par ce <a href="http://ec.europa.eu/transport/urban/vehicles/directive/directive_en.htm" target="_blank"><strong>lien</strong></a>. Un site portail a été développé : <a href="http://www.cleanvehicle.eu/" target="_blank"><strong>Clean Vehicle Portal</strong></a>. Elle permet de coupler les coûts économiques et les coûts dits externes, c'est à dire environnementaux. Le document ci dessous est un guide pour appliquer cette directive en France pour tous les achats publics :</p> <p><iframe frameborder="0" height="511" marginheight="0" marginwidth="0" scrolling="no" src="http://www.slideshare.net/slideshow/embed_code/13563173" style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" width="479"> </iframe></p> <div style="margin-bottom: 5px;"><strong> <a href="http://www.slideshare.net/transportsdufutur/ref-commandepubliquedevehicules" target="_blank" title="Ref -commande_publique_de_vehicules">Ref -commande_publique_de_vehicules</a> </strong> from <strong><a href="http://www.slideshare.net/transportsdufutur" target="_blank">Les transports du futur</a></strong></div>
