---
title: "Et si la Twizy était trop grande ? Kowa Tmsuk's Kobot"
date: 2011-12-09 14:09:41
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/12/et-si-la-twizy-etait-trop-grande-kowa-tmsuks-kobot.html
tags: [véhicule mono-usage, véhicule propre]
---

<p style="text-align: justify;"><a rel="lightbox" href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0162fd9468a9970d-800wi.jpg"><img rel="lightbox[]" class="asset  asset-image at-xid-6a0120a66d2ad4970b0162fd9468a9970d" style="display: block; margin-left: auto; margin-right: auto;" title="Kobot_560" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0162fd9468a9970d-500wi.jpg" alt="Kobot_560" /></a><br /><br />Conçu pour être intégré à des services de mobilité (auto-partage), communicant et extrêmement compact, ces robots-véhicules préfigurent sans doute les briques mobiles des futurs systèmes de mobilité intégrés.</p> <p style="text-align: justify;"> </p> <iframe width="560" height="315" src="http://www.youtube.com/embed/6sqljRqBvaU" frameborder="0" allowfullscreen></iframe>
