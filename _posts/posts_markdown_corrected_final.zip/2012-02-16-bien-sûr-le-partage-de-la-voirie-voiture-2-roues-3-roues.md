---
title: "Bien sûr le partage de la voirie, voiture, 2 roues, 3 roues, vélos, piétons... est un problème récent"
date: 2012-02-16 10:12:13
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/02/bien-sur-le-partage-de-la-voirie-voiture-2-roues-3-roues-velos-pietons-est-un-probleme-recent.html
tags: [cité, Infrastructure, management de la mobilité, mode doux, multimodes, partage de la voirie, véhicule mono-usage, vélo]
---

<p><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0163017a034d970d-pi.jpg"><img alt="Mix" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b0163017a034d970d image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0163017a034d970d-800wi.jpg" title="Mix" /></a></p>
