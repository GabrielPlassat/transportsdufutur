---
title: "Géographie des Transports Mondiaux - Arte.tv"
date: 2012-03-13 21:58:12
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/03/geographie-des-transports-mondiaux-artetv.html
tags: [nan]
---

<p style="text-align: justify;">Aujourd’hui, nous nous déplaçons de plus en plus vite, de plus en plus  loin et de plus en plus nombreux. Cela contribue à accroître la demande  mondiale de transport, et cette tendance va se poursuivre. <a href="http://ddc.arte.tv/emission/geographie-des-transports-mondiaux" target="_blank"><strong>Le Dessous  des Cartes</strong></a> cherche à mieux comprendre les facteurs de cette  augmentation, liée aux mobilités individuelles mais aussi au commerce de  marchandises : 13 mars 2012 à 22h05 et 17 mars 2012 à 14h05</p> <p><iframe frameborder="no" height="580" scrolling="no" src="http://ddc.arte.tv/cartes/162" width="500"></iframe></p>
