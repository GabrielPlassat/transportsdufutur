---
title: "Appel à projet ADEME, comment mettre l’innovation sur la trajectoire du facteur 4 ?"
date: 2010-11-16 16:38:59
permalink: https://gabrielplassat.github.io/transportsdufutur/2010/11/appel-a-projet-ademe-comment-mettre-linnovation-sur-la-trajectoire-du-facteur-4.html
tags: [ADEME, innovation, Service de mobilité]
---

<p style="text-align: justify">L'ADEME lance pour une durée de 2 ans minimum un nouveau programme de recherches en sciences humaines et sociales sur la question suivante « comment mettre l’innovation sur la trajectoire du facteur 4 ? ». Les défis sont nombreux et nous sommes convaincus que votre expertise nous aidera à les relever. Nous vous invitons donc à répondre à l'appel à projets de recherche, que vous trouverez sur le site internet de <strong><a href="http://www.ademe.fr" target="_blank">l’ADEME </a></strong>(Rubrique Appels à propositions). Date limite de réponse: 14 janvier 2011. </p>  <!--more-->   <div id="__ss_5798572" style="width: 477px"><strong style="margin: 12px 0 4px"><a href="http://www.slideshare.net/transportsdufutur/apr1-innovation-facteur415112010" title="Apr1 innovation facteur4_15-11-2010">Apr1 innovation facteur4_15-11-2010</a></strong>        <div style="padding: 5px 0 12px">View more <a href="http://www.slideshare.net/">documents</a> from <a href="http://www.slideshare.net/transportsdufutur">transportsdufutur</a>.</div> </div>
