---
title: "Mobility 3.0 - présentation ppt avec films liés"
date: 2011-04-19 14:00:00
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/04/mobility-30-presentation-ppt-avec-films-lies.html
tags: [ADEME, citoyen, connectivité, données réelles, pensée complexe]
---

<div id="__ss_7639514" style="text-align: center; width: 425px;"><strong style="display: block; margin: 12px 0 4px;"><a href="http://www.slideshare.net/transportsdufutur/ifpschool" title="IFP_school">IFP_school</a></strong> <iframe frameborder="0" height="355" marginheight="0" marginwidth="0" scrolling="no" src="http://www.slideshare.net/slideshow/embed_code/7639514" width="425"></iframe> <div style="padding: 5px 0 12px;">View more <a href="http://www.slideshare.net/">presentations</a> from <a href="http://www.slideshare.net/transportsdufutur">transportsdufutur</a></div> </div>
