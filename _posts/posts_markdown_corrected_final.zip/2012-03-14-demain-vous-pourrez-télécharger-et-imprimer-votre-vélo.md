---
title: "Demain vous pourrez télécharger et imprimer votre vélo"
date: 2012-03-14 09:58:56
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/03/demain-vous-pourrez-telecharger-et-imprimer-votre-velo.html
tags: [connectivité, donnée data, Fablab, gratuit, innovation, intelligence collective, internet, internet des objets, open innovation, open source, partage de données, simplicité, transition générationnelle]
---

<p style="text-align: justify;">C'est le début de l'impression 3D. Certains y verront un gadget, <a href="http://www.internetactu.net/2012/03/14/lift12-limpression-3d-va-bouleverser-lindustrie/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+internetactu/bcmJ+%28InternetActu.net%29&utm_content=Google+Reader&utm_source=twitterfeed&utm_medium=twitter" target="_blank"><strong>d'autres un bouleversement de l'industrie</strong></a>, des frontières avec le consommateur, et bien sûr des relations entre consommateurs. Il devient possible de télécharger les plans d'un vélo, de l'imprimer chez soi ou dans une usine locale partagée, un <a href="http://owni.fr/2011/09/23/leroy-merlin-se-paye-les-labos-citoyens/" target="_blank"><strong>fablab</strong></a>. La matière se transforme au plus près du consommateur, au plus près du besoin, au dernier moment. <strong>Combien de temps pour imaginer imprimer une voiture ?</strong></p> <p><iframe frameborder="0" height="315" src="http://www.youtube.com/embed/hmxjLpu2BvY" width="560"></iframe></p>
