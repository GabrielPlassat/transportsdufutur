---
title: "Mobilités Mutations (synthèse)"
date: 2014-04-16 17:10:42
permalink: https://gabrielplassat.github.io/transportsdufutur/2014/04/mobilites-mutations-synthese.html
tags: [nan]
---

<p style="text-align: justify;">Issue du séminaire des 3 et 4/12, cette synthèse réalisée pour l'<strong>ADEME</strong> par <a href="http://www.juliendelabaca.fr/" target="_blank"><strong>Julien Delabaca</strong></a> présente les intervenants et interventions, les vidéos, toutes les productions et les livrables, les actions en cours et la méthodologie développée par <a href="http://www.inprincipo.com/" target="_blank"><strong>In Principo</strong></a> . Merci à tous !</p> <p><iframe allowfullscreen="" frameborder="0" height="511" marginheight="0" marginwidth="0" scrolling="no" src="http://www.slideshare.net/slideshow/embed_code/33603533" style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px; max-width: 100%;" width="479"> </iframe></p> <div style="margin-bottom: 5px;"><strong> <a href="https://fr.slideshare.net/transportsdufutur/synthese-mobilites-mutations-2" target="_blank" title="Synthese mobilites mutations (2)">Synthese mobilites mutations (2)</a> </strong> from <strong><a href="http://www.slideshare.net/transportsdufutur" target="_blank">Les transports du futur</a></strong></div>
