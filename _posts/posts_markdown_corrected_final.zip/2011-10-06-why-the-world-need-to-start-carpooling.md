---
title: "Why the world need to start #Carpooling"
date: 2011-10-06 08:27:10
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/10/why-the-world-need-to-start-carpooling.html
tags: [nan]
---

<p><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b015435ede740970c-pi.jpg"><img alt="Carpooling" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b015435ede740970c image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b015435ede740970c-800wi.jpg" title="Carpooling" /></a></p>
