---
title: "Un observatoire de la Précarité énergétique dans les transports - Appel à Participation"
date: 2011-11-16 09:21:27
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/11/un-observatoire-de-la-precarite-energetique-dans-les-transports-appel-a-participation.html
tags: [citoyen, collectivité, Précarité]
---

<p style="text-align: justify">Un <a href="http://www.developpement-durable.gouv.fr/L-Observatoire-national-de-la,21540.html" target="_blank"><strong>observatoire </strong></a>a été mis en oeuvre il y a quelques mois sur le sujet rassemblant Ministères, Agences, Acteurs économiques et associations. Historiquement focalisé sur l'habitat, la mobilité est maintenant intégrée à la réflexion dans une approche plus globale.</p> <p style="text-align: justify">Dans le domaine des transports, nous cherchons des entreprises, organismes intéressés pour participer à cet observatoire, renforcer les compétences et expertises et proposer des actions. L'ordre de grandeur de la participation est de : 90.000 € pour 3 ans, soit 30.000 €/an.</p> <p style="text-align: justify"><strong>Contact </strong>: gabriel.plassat@ademe.fr, didier.cherel@ademe.fr</p>
