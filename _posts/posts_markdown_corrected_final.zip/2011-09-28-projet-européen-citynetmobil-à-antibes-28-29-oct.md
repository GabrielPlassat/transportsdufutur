---
title: "Projet européen CityNetMobil à Antibes 28-29 oct"
date: 2011-09-28 18:12:59
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/09/projet-europeen-citynetmobil-a-antibes-28-29-oct.html
tags: [nan]
---

<p style="text-align: justify">Le projet européen <a href="http://www.citynetmobil.org/" target="_self"><strong>CityNetMobil </strong></a>vise à expérimenter de nouveaux modes de transports. Deux jours d'échanges, de débats et d'essais sont prévus à Antibes (06) les 28 et 29 octobre.</p> <p><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b015391eded91970b-pi.jpg"><img alt="Ruedufutur" border="0" class="asset  asset-image at-xid-6a0120a66d2ad4970b015391eded91970b image-full" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b015391eded91970b-800wi.jpg" style="margin-left: auto;margin-right: auto" title="Ruedufutur" /></a> <br /><br /></p> <p>        </p>
