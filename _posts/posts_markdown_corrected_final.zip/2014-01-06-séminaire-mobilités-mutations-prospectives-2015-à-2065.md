---
title: "Séminaire Mobilités Mutations, Prospectives 2015 à 2065"
date: 2014-01-06 11:41:07
permalink: https://gabrielplassat.github.io/transportsdufutur/2014/01/seminaire-mobilites-mutations-prospectives-2015-a-2065.html
tags: [nan]
---

<p style="text-align: justify;">Après avoir identifiés des <a href="https://gabrielplassat.github.io/transportsdufutur/2013/12/mur-des-defis.html" target="_blank"><strong>défis</strong></a>, les participants du <a href="https://gabrielplassat.github.io/transportsdufutur/2013/12/tweet-feed-back-du-seminaire-mobilites-mutations.html" target="_blank"><strong>séminaire Mobilités Mutations</strong></a> se sont groupés en équipes. Ils ont décrit et dessiné des futurs, une des premières étapes pour raconter des histoires et des fictions (lire les <a href="https://gabrielplassat.github.io/transportsdufutur/les-fictions-comme-accelerateur-creatif" target="_blank"><strong>6 fictions des Transports du Futur</strong></a>). <strong>De 2015 à 2065 ... </strong></p> <p style="text-align: justify;">Les jugez vous probable ? souhaitable ?</p> <p style="text-align: justify;">Sur une page, quel est, pour vous, un futur crédible et souhaitable ?</p> <p><iframe frameborder="0" height="400" marginheight="0" marginwidth="0" scrolling="no" src="http://www.slideshare.net/slideshow/embed_code/29725485" width="476"></iframe></p>
