---
title: "Construisons un arbre de connaissance commun sur le vélo"
date: 2011-09-05 10:58:34
permalink: https://gabrielplassat.github.io/transportsdufutur/2011/09/construisons-un-arbre-de-connaissance-commun-sur-le-velo.html
tags: [2 roues, internet, open innovation, vélo]
---

<p>Cliquez sur une perle, prenez une perle ou tout l'arbre, ou faisons équipe (<a href="http://pear.ly/RENj" target="_blank">ICI</a>) pour construire ensemble un arbre de connaissance :</p> <p>        </p>
