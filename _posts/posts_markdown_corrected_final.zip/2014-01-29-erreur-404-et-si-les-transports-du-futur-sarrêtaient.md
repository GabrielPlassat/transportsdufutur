---
title: "Erreur 404, Et si les Transports du Futur s’arrêtaient ?"
date: 2014-01-29 12:20:36
permalink: https://gabrielplassat.github.io/transportsdufutur/2014/01/erreur-404-et-si-les-transports-du-futur-sarretaient.html
tags: [nan]
---

<p style="text-align: justify">Créé en 2009, ce dispositif s'est développé et enrichi. Vos retours, idées, commentaires, encouragements, critiques sont essentiels pour réorganiser, amplifier, consolider et revoir des concepts et des propositions. Vos liens, propagations, amplifications ont progressivement construit un dispositif inédit par sa reliance. </p> <p style="text-align: justify">Ce sont les principales richesses et nous avons du mal à les révéler. Un petit <a href="http://981936.polldaddy.com/s/les-transports-du-futur-error-404" target="_blank"><strong>questionnaire</strong></a> pour définir la suite, et un <a href="http://www.linkedin.com/in/plassat" target="_blank"><strong>lien</strong></a> pour ceux qui souhaitent compléter les compétences et expertises mises en oeuvre.</p> <p> </p>
