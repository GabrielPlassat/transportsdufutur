---
title: "train+vélo=vélo+train, individuel+collectif / public+privé"
date: 2012-01-16 18:12:02
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/01/trainvelovelotrain-individuelcollectif-publicprive.html
tags: [TC, vélo]
---

<p style="text-align: justify">Et si les principales innovations étaient dans les intermédiaires, les interstices, le couplage, l'hybridation des modes existants ... Au <a href="http://www.bv.com.au/general/bikes-and-riding/42382/" target="_blank"><strong>Danemark </strong></a>:</p> <p style="text-align: justify"><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b016760a1ba8f970b-800wi.jpg" rel="lightbox"><img alt="Train_vélo" class="asset  asset-image at-xid-6a0120a66d2ad4970b016760a1ba8f970b" src="/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b016760a1ba8f970b-500wi.jpg" style="margin-left: auto;margin-right: auto" title="Train_vélo" /></a><br /><br /><br /></p>
