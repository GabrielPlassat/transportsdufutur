---
title: "Et si les chinois re-inventaient aussi les modes de transports urbains #lessismore"
date: 2012-03-20 10:42:56
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/03/et-si-les-chinois-re-inventaient-aussi-les-modes-de-transports-urbains-lessismore.html
tags: [Efficacité énergétique, VE, véhicule mono-usage, vélo]
---

<p style="text-align: justify">Ce thème, largement développé sur le blog de François Bellanger (<a href="http://transit-city.blogspot.fr/2011/12/beijing-big-return-of-bike-2.html" target="_blank"><strong>Beijing</strong></a>), trouve dans cette photo un écho immédiat. Après l'Italie qui la première à développer les modes hybrides intermédiaires" microvoiture-3roues, la Chine doit inventer ses mobilités et les objets-véhicules qui vont avec :</p> <p><a href="https://gabrielplassat.github.io/transportsdufutur/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0167640429fb970b-pi.jpg""><img alt=""ABeijing-China-Passengers-005"" border=""0"" class=""asset  asset-image at-xid-6a0120a66d2ad4970b0167640429fb970b image-full"" src=""/wp-content/uploads/sites/6/old/6a0120a66d2ad4970b0167640429fb970b-800wi.jpg"" title=""ABeijing-China-Passengers-005"" /></a></p> <p>source : Le <a href=""http://www.guardian.co.uk/news/gallery/2012/mar/15/1#/?picture=387381656&index=0"" target=""_blank""><strong>Guardian</strong></a></p>"
