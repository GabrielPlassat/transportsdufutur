---
title: "La PEEL #lessismore"
date: 2012-03-23 18:22:13
permalink: https://gabrielplassat.github.io/transportsdufutur/2012/03/la-peel-lessismore.html
tags: [allégement, léger, low cost, véhicule mono-usage, véhicule propre]
---

<p>La plus petite voiture au monde, la <a href="http://www.peelengineering.co.uk/" target="_blank"><strong>Peel </strong></a>(déjà mentionnée dans ce blog dans un précédent <a href="https://gabrielplassat.github.io/transportsdufutur/2012/02/50-ans-apres-toute-ressemblance-avec-la-situation-actuelle-ne-serait-que-pure-fiction.html" target="_blank"><strong>article</strong></a>) dans les rues et ailleurs ...</p> <p><iframe frameborder="0" height="315" src="http://www.youtube.com/embed/vW6BTlfUmck" width="560"></iframe></p>
